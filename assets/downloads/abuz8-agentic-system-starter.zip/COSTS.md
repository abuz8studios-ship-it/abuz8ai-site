# Real Costs

Costs vary by usage. These are practical ranges for a starter agentic system.

## Local-First Setup

| Item | Typical Cost |
|---|---:|
| Existing Windows/Mac/Linux computer | $0 if owned |
| Ollama/local model runtime | $0 |
| Open-source agent frameworks | $0 |
| Browser automation | $0 |
| GitHub public repos | $0 |
| GitHub private repos | $4/mo+ if needed |
| Domain | $10-$20/year |
| Cloudflare Pages/Workers starter usage | $0-$5/mo |

## Cloud/API Add-ons

| Service | Typical Starter Cost |
|---|---:|
| OpenAI/Anthropic/Gemini APIs | $5-$100/mo |
| xAI/Grok API | usage based |
| Stripe | transaction fee only |
| Gmail/Google Workspace | $0 Gmail or $7+/user/mo Workspace |
| Email sending service | $0-$20/mo starter |
| Vector DB hosted tier | $0-$50/mo |
| Logging/evals | $0-$50/mo |

## ABUZ8 Suggested Buyer Pricing

| Tier | Price | Buyer |
|---|---:|---|
| Starter kit | $49-$99 | self-setup operators |
| Pro kit | $149-$297 | agencies/builders needing extra packs |
| Setup help | $497-$1,500 | nontechnical operators |
| Managed ops | $2,000+/mo | teams that want ABUZ8 to run it |
| Enterprise deployment | $5,000-$25,000+ | custom workflows, security, integrations |

## Cost Control Rules

- Route easy tasks to local or cheap models.
- Use premium models only for hard reasoning, legal-risk review, or final sales assets.
- Put spending caps in provider dashboards.
- Log every paid model/tool call.
- Never let an agent move money, issue refunds, or buy services without approval.

