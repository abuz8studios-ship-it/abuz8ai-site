# Setup Guide

This guide sets up the starter version of a local-first agentic system. The stack is designed to work in layers. Start with local files and browser control, then add email, GitHub, Stripe, and Cloudflare as needed.

## 1. Required Tools

Install or verify:

```powershell
git --version
node --version
npm --version
python --version
gh --version
```

Recommended:

```powershell
ollama --version
openclaw --version
wrangler --version
stripe --version
himalaya --version
```

## 2. Workspace

Create a workspace:

```powershell
New-Item -ItemType Directory -Force C:\agentic-system | Out-Null
New-Item -ItemType Directory -Force C:\agentic-system\memory,C:\agentic-system\agents,C:\agentic-system\workflows,C:\agentic-system\products | Out-Null
```

Copy this package into:

```text
C:\agentic-system\products\abuz8-agentic-system-starter
```

## 3. Environment

Copy:

```powershell
Copy-Item .env.example .env
```

Fill only the keys you need. Do not commit `.env`.

Minimum:

```text
AGENT_WORKSPACE=C:\agentic-system
LOCAL_MODEL_PROVIDER=ollama
LOCAL_MODEL=llama3.1:8b
```

## 4. Local Model

Install Ollama, then pull a model:

```powershell
ollama pull llama3.1:8b
ollama list
```

For stronger local machines:

```powershell
ollama pull qwen2.5-coder:32b
```

## 5. Browser Control

Use Playwright or the browser connector from your agent runtime.

```powershell
npx playwright install chromium
```

Principle: the browser should use your signed-in profile when possible, but secrets should remain in the browser/session store. Do not export cookies into docs or chat.

## 6. Gmail With Himalaya

Preferred: OAuth through your agent platform or Google Workspace connector.

Fallback: Gmail app password with 2FA enabled.

Use account names:

```text
wireconn1
abuz8studios
```

Store app passwords in Windows Credential Manager or another local secret store. Himalaya config should call a secure command that returns the password without printing it.

Verify:

```powershell
himalaya account list
himalaya --account wireconn1 folder list
himalaya --account abuz8studios folder list
```

## 7. GitHub

Authenticate:

```powershell
Remove-Item Env:GITHUB_TOKEN -ErrorAction SilentlyContinue
gh auth login
gh auth status
```

Use GitHub for product repos, docs, issue tracking, and release packages.

## 8. Stripe

Use the CLI for product and payment-link management:

```powershell
stripe login
stripe products list --limit 3
```

Safer production option: create a restricted key with product, price, checkout, payment-link, and analytics permissions only. Do not include refunds, payouts, transfers, bank, or balance permissions.

## 9. Cloudflare

Verify:

```powershell
wrangler whoami
wrangler pages project list
```

Use Cloudflare for:

- product landing pages
- worker-based lead capture
- webhook receivers
- static downloads
- DNS and analytics

## 10. First Agent

Start with `agents/revenue-operator.md`.

The first agent should not do everything. Give it one job:

```text
Find one painful buyer problem, create one free teardown, package one paid setup offer, draft one outreach sequence.
```

## 11. First Workflow

Run:

```text
workflows/free-teardown-to-paid-setup.md
```

Output should be:

- target profile
- teardown angle
- public post or PDF
- CTA
- product repo checklist
- offer price
- approved outreach draft

