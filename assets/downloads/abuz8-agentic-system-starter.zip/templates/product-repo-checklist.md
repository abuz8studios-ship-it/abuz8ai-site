# Product Repo Checklist

## Required Files

- [ ] `README.md`
- [ ] `SETUP.md`
- [ ] `FAQ.md`
- [ ] `COSTS.md`
- [ ] `.env.example`
- [ ] `docs/troubleshooting.md`
- [ ] `docs/demo-script.md`
- [ ] `templates/`
- [ ] `agents/` if agent-based
- [ ] `workflows/` if workflow-based

## README Must Answer

- [ ] What is this?
- [ ] Who is it for?
- [ ] What outcome does it create?
- [ ] What is included?
- [ ] What is not included?
- [ ] What is the upgrade path?

## Setup Must Include

- [ ] prerequisites
- [ ] install commands
- [ ] environment variables
- [ ] auth steps
- [ ] verification commands
- [ ] first workflow

## Cost Must Include

- [ ] local costs
- [ ] API costs
- [ ] hosting costs
- [ ] email costs
- [ ] payment processing fees
- [ ] optional managed service pricing

## Sales Must Include

- [ ] free teardown angle
- [ ] CTA
- [ ] starter price
- [ ] pro price
- [ ] setup/help price
- [ ] managed ops price

