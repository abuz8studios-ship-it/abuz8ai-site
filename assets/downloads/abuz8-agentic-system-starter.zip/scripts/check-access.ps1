$ErrorActionPreference = "Continue"

$commands = @(
  "git",
  "node",
  "npm",
  "python",
  "gh",
  "wrangler",
  "stripe",
  "himalaya",
  "ollama"
)

foreach ($cmd in $commands) {
  $found = Get-Command $cmd -ErrorAction SilentlyContinue
  if ($found) {
    Write-Output "$cmd OK -> $($found.Source)"
  } else {
    Write-Output "$cmd MISSING"
  }
}

Write-Output ""
Write-Output "Secret presence checks only. Values are not printed."
Write-Output "CLOUDFLARE_API_TOKEN present: $([bool]$env:CLOUDFLARE_API_TOKEN)"
Write-Output "STRIPE_API_KEY present: $([bool]$env:STRIPE_API_KEY)"
Write-Output "GITHUB_TOKEN present: $([bool]$env:GITHUB_TOKEN)"
Write-Output "OPENAI_API_KEY present: $([bool]$env:OPENAI_API_KEY)"
Write-Output "ANTHROPIC_API_KEY present: $([bool]$env:ANTHROPIC_API_KEY)"

