# Workflow: Product Repo Packaging

## Purpose

Turn an internal build into something a buyer can understand, install, and trust.

## Steps

1. Define the buyer in one sentence.
2. Define the painful problem in one sentence.
3. Define the promised outcome in one sentence.
4. Create required files:
   - `README.md`
   - `SETUP.md`
   - `FAQ.md`
   - `COSTS.md`
   - `.env.example`
   - `docs/troubleshooting.md`
5. Add a demo script.
6. Add a cost section.
7. Add safety boundaries.
8. Add upgrade path.
9. Run a clean install test.
10. Create the checkout or waitlist CTA.

## Done Means

A stranger can open the repo and know:

- what it does
- who it is for
- what it costs
- how to install it
- what can break
- how to get help
- what the paid upgrade is

