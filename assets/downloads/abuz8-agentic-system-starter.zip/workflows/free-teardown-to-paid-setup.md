# Workflow: Free Teardown To Paid Setup

## Purpose

Convert visible business pain into trust, then sell the setup system that fixes it.

## Steps

1. Pick one buyer segment.
2. Find one public example with visible friction.
3. Write the teardown:
   - symptom
   - hidden cause
   - cost
   - agentic fix
   - first step
4. Create a CTA to the paid setup.
5. Package the setup using `templates/product-repo-checklist.md`.
6. Draft outreach:
   - direct message
   - email
   - public post
   - 3 follow-ups
7. Log replies and objections.
8. Convert repeated objections into FAQ entries.

## Teardown Prompt

```text
You are analyzing a business from public information only. Identify the highest-cost operational bottleneck visible from the outside. Write a useful teardown that gives real value, then pitch a local-first agentic setup kit as the implementation path.
```

## Success Metric

- one public teardown published
- one paid setup CTA
- one outreach list
- one reply or buyer objection logged

