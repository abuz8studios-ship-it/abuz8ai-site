# FAQ

## Is this a chatbot?

No. A chatbot answers. An agentic system uses tools, files, browser sessions, memory, and workflows to execute repeatable work under your control.

## Do I need to code?

Basic command line comfort helps. The starter kit is written for operators who can copy commands, edit `.env`, and follow setup steps.

## Can this use my Gmail?

Yes, through OAuth or Gmail app passwords. Do not paste Gmail passwords into chat. Store credentials locally and use Himalaya or your platform's Gmail connector.

## Can it send emails?

Technically yes. Operationally, start with draft-only. Move to sending only after templates, lead lists, and approval rules are clear.

## Can it manage Stripe?

It can help create products, prices, checkout links, and reports if you authorize it. Do not grant refunds, payouts, transfers, or bank permissions to an autonomous agent.

## Can it deploy websites?

Yes, if Cloudflare or another deploy target is authenticated. Cloudflare Pages plus Workers is the recommended starter path.

## What is the first revenue move?

Publish a free teardown of a painful business problem for a specific buyer. Then CTA into the paid personal agent setup package.

## Why free teardown instead of paid audit?

The teardown proves insight publicly and creates demand. The paid product is the setup system, templates, agent packs, and optional implementation help.

## What makes this different from a prompt pack?

It is a system pack: agents, workflows, access model, costs, setup docs, troubleshooting, and product packaging. Prompts are only one layer.

## What is the biggest risk?

Credential sprawl. Keep access scoped, local, and auditable. Do not share passwords in chat. Use least privilege.

