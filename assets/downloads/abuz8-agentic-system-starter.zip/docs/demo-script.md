# Demo Script

Use this to sell the starter kit in 5 minutes.

## 0:00 - Frame

```text
Most people are using AI as a chat tab. This setup turns it into a local operator: it can use files, browser, memory, email, GitHub, Stripe, Cloudflare, and repeatable workflows under your approval rules.
```

## 0:45 - Show The Workspace

Open the package folder:

- `agents/`
- `workflows/`
- `templates/`
- `docs/`
- `.env.example`

```text
This is not just prompts. It is the operating layer: agents, workflows, access model, setup guide, costs, and troubleshooting.
```

## 1:30 - Show A Workflow

Open `workflows/free-teardown-to-paid-setup.md`.

```text
The first revenue move is not selling an audit. It is publishing a free teardown that proves the problem, then selling the setup system.
```

## 2:30 - Show Access Model

Open `.env.example` and `SETUP.md`.

```text
Keys stay local. Gmail uses OAuth or app passwords. Stripe gets restricted permissions. Cloudflare gets scoped deploy access. The agent can operate, but money movement and destructive actions require human approval.
```

## 3:30 - Show Agent Briefs

Open `agents/revenue-operator.md`.

```text
This agent has one job: find painful buyer problems, build teardowns, package the paid setup, and draft approved outreach.
```

## 4:30 - Close

```text
You can buy the starter kit and install it yourself, buy the pro pack for more agents and workflows, or pay ABUZ8 to set it up and operate it with you.
```

