# Troubleshooting

## `gh auth status` shows the wrong account

Clear temporary token shadowing:

```powershell
Remove-Item Env:GITHUB_TOKEN -ErrorAction SilentlyContinue
gh auth status
```

Then run:

```powershell
gh auth login
```

## `wrangler whoami` fails

Check token presence without printing it:

```powershell
[bool]$env:CLOUDFLARE_API_TOKEN
[bool][Environment]::GetEnvironmentVariable('CLOUDFLARE_API_TOKEN','User')
[bool][Environment]::GetEnvironmentVariable('CLOUDFLARE_API_TOKEN','Machine')
```

If missing, create a scoped Cloudflare API token and store it locally.

## Stripe CLI is installed but unauthenticated

Run:

```powershell
stripe login
stripe products list --limit 3
```

Use restricted keys for unattended work.

## Himalaya cannot list Gmail folders

Check:

- IMAP is enabled in Gmail settings
- 2FA is enabled if using app passwords
- account name is correct
- secure password command returns the value without extra spaces

Run:

```powershell
himalaya account list
himalaya --account wireconn1 folder list
```

## Agent uses expensive models too often

Set routing rules:

- drafts and summaries: local/cheap
- strategy and final assets: premium
- code review: premium only when high risk
- public legal/medical/financial claims: human review

## Browser automation fails

Run:

```powershell
npx playwright install chromium
```

Then test a simple navigation before using a logged-in profile.

